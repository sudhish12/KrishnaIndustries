const o=""+new URL("logo (1)-DahH5gU4.png",import.meta.url).href;export{o as l};
